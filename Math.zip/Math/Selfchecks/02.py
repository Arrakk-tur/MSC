import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

#Data
sleep_duration_data = [6.0, 7.0, 8.0, 6.0, 8.0, 6.0, 10.0, 6.0, 9.0, 8.0, 7.5, 9.0, 8.5, 8.5, 7.5, 7.0, 7.5, 9.0, 8.0, 7.5, 8.0, 8.0, 6.0, 7.0, 9.0, 7.0, 7.0, 8.0, 7.0, 7.5, 7.0, 7.0, 7.5, 7.0, 6.0, 6.0, 10.0, 7.5, 8.0, 7.0, 8.0, 7.5, 8.0, 7.0, 7.0, 7.5, 8.5, 8.5, 7.5, 9.0, 8.0, 7.0, 7.5, 7.0, 8.0, 7.0, 7.5, 7.0, 6.0, 7.5, 7.0, 6.0, 7.5, 7.0, 7.0, 9.0, 7.0, 7.5, 8.5, 7.5, 7.5, 8.0, 6.0, 7.0, 7.0, 7.5, 7.5, 5.0, 8.0, 7.0, 7.0, 7.5, 7.0, 7.0, 7.5, 9.0, 8.0, 8.0, 8.5, 8.0, 6.0, 6.0, 8.0, 7.0, 8.5, 8.0, 7.5, 5.0, 7.0, 8.0, 6.0, 7.0, 8.0, 8.0, 7.0, 7.0, 6.0, 8.0, 7.0, 7.0, 8.0, 7.0, 7.0, 9.0, 8.0, 8.0, 7.5, 8.0, 7.0, 7.0, 9.0, 6.0, 7.0, 7.0, 7.0, 8.0, 8.0, 8.5, 7.0, 7.5, 7.5, 7.5, 7.5, 7.5, 7.0, 7.0, 8.5, 7.0, 7.5, 7.0, 7.0, 7.0, 7.0, 7.0, 7.5, 7.5, 8.0, 6.0, 8.0, 7.5, 7.0, 8.0, 6.0, 7.5, 7.0, 7.5, 8.0, 7.5, 7.0, 8.0, 7.0, 7.5, 8.0, 7.0, 8.0, 7.0, 8.0, 6.0, 5.0, 7.0, 7.0, 8.0, 6.0, 7.0, 6.0, 7.0, 7.0, 8.0, 9.0, 7.0, 7.0, 7.5, 5.0, 7.5, 6.0, 7.5, 7.0, 8.0, 7.0, 8.5, 8.0, 8.5, 6.0, 8.0, 7.5, 7.0, 8.0, 7.0, 7.5, 8.0, 5.0, 8.0, 9.0, 7.0, 7.5, 7.5, 8.5, 8.0, 7.0, 8.5, 8.0, 7.0, 8.5, 8.5, 8.0, 7.5, 7.0, 8.5, 7.0, 6.0, 7.0, 7.0, 7.0, 8.0, 8.0, 7.5, 7.0, 7.0, 9.0, 7.0, 7.5, 7.0, 8.0, 8.5, 7.0, 7.0, 9.0, 7.0, 7.0, 7.0, 8.0, 8.0, 8.0, 7.0, 7.5, 7.5, 7.0, 8.5, 7.0, 6.0, 8.0, 7.0, 8.0, 7.5, 6.0, 7.0, 7.0, 8.0, 7.0, 8.0, 8.5, 8.0, 7.0, 8.5, 7.0, 10.0, 5.0, 6.0, 7.0, 7.5, 10.0, 7.0, 9.0, 7.0, 7.0, 7.5, 7.5, 8.0, 7.0, 7.0, 7.5, 6.0, 7.0, 7.5, 8.0, 7.5, 5.5, 8.0, 9.0, 7.5, 8.5, 10.0, 10.0, 5.5, 7.0, 8.0, 8.0, 7.0, 9.0, 7.0, 7.0, 8.0, 7.0, 7.5, 7.0, 7.5, 7.5, 7.0, 8.0, 9.0, 7.0, 9.0, 9.0, 6.0, 7.5, 10.0, 8.0, 7.0, 5.0, 7.5, 6.0, 7.0, 7.0, 8.0, 8.0, 7.5, 9.0, 8.0, 8.0, 7.0, 7.0, 7.0, 7.0, 7.5, 9.0, 7.0, 8.0, 7.0, 7.0, 8.0, 8.0, 5.0, 7.0, 8.0, 7.0, 8.0, 7.0, 7.5, 8.0, 7.5, 8.0, 8.0, 7.0, 8.0, 8.0, 7.0, 7.0, 7.0, 8.5, 8.0, 7.0, 7.0, 7.0, 9.0, 8.5, 7.0, 7.0, 7.5, 8.0, 6.0, 8.0, 8.0, 7.5, 6.0, 7.0, 8.0, 7.5, 7.0, 8.0, 8.0, 6.0, 7.5, 9.0, 7.5, 7.5, 7.5, 7.5, 6.0, 7.0, 7.5, ]
sleep_efficiency_data = [0.88, 0.66, 0.89, 0.51, 0.76, 0.54, 0.9, 0.79, 0.55, 0.92, 0.93, 0.93, 0.64, 0.54, 0.92, 0.54, 0.5, 0.98, 0.83, 0.71, 0.84, 0.98, 0.91, 0.84, 0.65, 0.91, 0.57, 0.68, 0.55, 0.94, 0.64, 0.87, 0.87, 0.63, 0.83, 0.83, 0.59, 0.87, 0.77, 0.86, 0.91, 0.71, 0.81, 0.81, 0.71, 0.71, 0.52, 0.65, 0.84, 0.84, 0.99, 0.71, 0.8, 0.91, 0.77, 0.84, 0.87, 0.8, 0.52, 0.54, 0.88, 0.64, 0.87, 0.77, 0.94, 0.7, 0.79, 0.77, 0.86, 0.81, 0.88, 0.78, 0.64, 0.78, 0.71, 0.97, 0.77, 0.8, 0.94, 0.52, 0.76, 0.73, 0.73, 0.96, 0.91, 0.8, 0.77, 0.81, 0.71, 0.95, 0.64, 0.94, 0.87, 0.63, 0.88, 0.9, 0.94, 0.91, 0.9, 0.8, 0.85, 0.53, 0.87, 0.5, 0.93, 0.72, 0.92, 0.62, 0.93, 0.63, 0.77, 0.51, 0.94, 0.73, 0.55, 0.83, 0.94, 0.95, 0.59, 0.77, 0.65, 0.51, 0.81, 0.75, 0.57, 0.58, 0.81, 0.53, 0.93, 0.89, 0.7, 0.74, 0.92, 0.93, 0.95, 0.6, 0.93, 0.81, 0.95, 0.72, 0.9, 0.91, 0.85, 0.9, 0.92, 0.67, 0.51, 0.78, 0.95, 0.68, 0.94, 0.78, 0.9, 0.83, 0.8, 0.96, 0.91, 0.96, 0.73, 0.87, 0.76, 0.68, 0.94, 0.62, 0.91, 0.67, 0.94, 0.79, 0.86, 0.83, 0.73, 0.71, 0.87, 0.92, 0.79, 0.98, 0.93, 0.88, 0.77, 0.86, 0.54, 0.8, 0.86, 0.61, 0.72, 0.55, 0.96, 0.58, 0.77, 0.85, 0.95, 0.69, 0.95, 0.82, 0.93, 0.82, 0.94, 0.75, 0.91, 0.65, 0.87, 0.84, 0.85, 0.91, 0.71, 0.82, 0.77, 0.95, 0.95, 0.76, 0.85, 0.75, 0.78, 0.91, 0.85, 0.95, 0.63, 0.86, 0.54, 0.95, 0.72, 0.52, 0.93, 0.52, 0.61, 0.79, 0.94, 0.76, 0.78, 0.94, 0.87, 0.55, 0.93, 0.93, 0.94, 0.94, 0.5, 0.93, 0.73, 0.9, 0.87, 0.93, 0.9, 0.67, 0.9, 0.9, 0.98, 0.66, 0.68, 0.56, 0.62, 0.81, 0.84, 0.93, 0.87, 0.86, 0.89, 0.94, 0.84, 0.86, 0.75, 0.6, 0.93, 0.75, 0.81, 0.78, 0.9, 0.9, 0.93, 0.8, 0.63, 0.9, 0.9, 0.86, 0.51, 0.87, 0.7, 0.85, 0.87, 0.6, 0.8, 0.75, 0.5, 0.5, 0.96, 0.52, 0.68, 0.72, 0.56, 0.91, 0.85, 0.72, 0.89, 0.9, 0.85, 0.95, 0.51, 0.9, 0.9, 0.51, 0.84, 0.82, 0.88, 0.79, 0.64, 0.84, 0.71, 0.9, 0.95, 0.95, 0.54, 0.95, 0.53, 0.92, 0.85, 0.92, 0.53, 0.75, 0.74, 0.87, 0.72, 0.87, 0.53, 0.72, 0.87, 0.66, 0.66, 0.72, 0.81, 0.88, 0.94, 0.83, 0.91, 0.95, 0.9, 0.95, 0.9, 0.62, 0.93, 0.79, 0.91, 0.52, 0.84, 0.67, 0.63, 0.64, 0.91, 0.82, 0.92, 0.92, 0.93, 0.87, 0.82, 0.73, 0.9, 0.68, 0.82, 0.74, 0.88, 0.72, 0.67, 0.87, 0.66, 0.66, 0.87, 0.79, 0.8, 0.55, 0.85, 0.88, 0.93, 0.63, 0.92, 0.8, 0.92, 0.77, 0.9, 0.96, 0.72, 0.86, 0.9, 0.5, 0.6, 0.67, 0.58, 0.53, 0.91, 0.74, 0.76, 0.63, ]
age_data = [65, 69, 40, 40, 57, 27, 53, 41, 11, 50, 55, 30, 28, 36, 32, 21, 40, 43, 24, 32, 29, 63, 52, 35, 23, 47, 24, 18, 26, 46, 61, 38, 28, 58, 46, 52, 29, 31, 34, 40, 55, 27, 21, 37, 29, 65, 9, 16, 18, 37, 54, 34, 34, 56, 21, 25, 52, 46, 40, 30, 32, 55, 58, 47, 47, 46, 43, 54, 55, 29, 66, 40, 50, 50, 50, 48, 24, 45, 57, 39, 43, 51, 61, 41, 53, 32, 65, 38, 53, 55, 44, 38, 40, 53, 24, 39, 47, 51, 25, 23, 54, 22, 50, 30, 52, 52, 51, 15, 48, 56, 25, 54, 37, 33, 29, 36, 32, 37, 27, 36, 52, 28, 48, 65, 31, 42, 40, 65, 50, 22, 41, 68, 61, 23, 45, 14, 30, 42, 42, 53, 49, 48, 40, 48, 35, 33, 27, 24, 48, 62, 44, 39, 53, 37, 29, 49, 24, 48, 27, 21, 52, 53, 27, 18, 44, 61, 30, 48, 32, 52, 61, 64, 59, 31, 32, 31, 41, 32, 61, 61, 10, 36, 29, 27, 22, 40, 56, 13, 37, 41, 52, 63, 38, 60, 29, 29, 30, 26, 32, 55, 36, 53, 18, 28, 58, 51, 37, 41, 32, 56, 43, 52, 67, 36, 29, 25, 29, 31, 23, 46, 47, 65, 35, 27, 54, 48, 46, 37, 23, 48, 44, 24, 30, 45, 27, 50, 58, 49, 46, 27, 37, 48, 42, 48, 25, 64, 53, 38, 17, 27, 50, 26, 54, 46, 38, 24, 38, 29, 51, 27, 35, 22, 47, 25, 25, 51, 65, 27, 56, 28, 33, 22, 50, 25, 54, 58, 45, 55, 54, 60, 30, 44, 52, 29, 42, 26, 49, 46, 12, 27, 39, 44, 44, 57, 53, 65, 41, 52, 53, 25, 51, 30, 57, 24, 24, 19, 45, 29, 51, 27, 41, 65, 56, 27, 28, 30, 37, 22, 56, 56, 41, 40, 32, 29, 39, 65, 60, 48, 21, 25, 61, 35, 22, 40, 39, 40, 32, 62, 48, 22, 36, 37, 56, 55, 57, 59, 30, 32, 37, 48, 38, 58, 53, 61, 32, 58, 53, 27, 51, 28, 49, 49, 44, 51, 21, 44, 41, 41, 19, 26, 54, 23, 52, 38, 37, 55, 29, 40, 59, 56, 55, 25, 46, 65, 24, 30, 27, 52, 45, 18, ]

# Модель 1

sleep_duration_simple = np.array(sleep_duration_data).reshape(-1, 1)
sleep_efficiency_simple = np.array(sleep_efficiency_data)

# Ініціалізація та навчання моделі
model_simple = LinearRegression().fit(sleep_duration_simple, sleep_efficiency_simple)
# model = LinearRegression().fit(sleep_duration_simple, sleep_efficiency_simple)

# Побудова прогнозу
sleep_duration_pred = np.array([min(sleep_duration_simple), max(sleep_duration_simple)]).reshape(-1, 1)
sleep_efficiency_pred = model_simple.predict(sleep_duration_pred)

# Побудова графіка
plt.scatter(sleep_duration_simple, sleep_efficiency_simple, color='blue')
plt.plot(sleep_duration_pred, sleep_efficiency_pred, color='red', linewidth=2)
plt.xlabel('Sleep duration')
plt.ylabel('Sleep efficiency')
plt.title('Проста лінійна регресія: Sleep efficiency ~ Sleep duration')
plt.savefig('linear_regression_model1.png')
plt.show()


# Модель 2

# Надані дані
sleep_duration_multi = np.array(sleep_duration_data).reshape(-1, 1)
age_multi = np.array(age_data).reshape(-1, 1)
sleep_efficiency_multi = np.array(sleep_efficiency_data)

# Підготовка ознак для моделі
X = np.concatenate((age_multi, sleep_duration_multi), axis=1)

# Ініціалізація та навчання моделі
model_multiple = LinearRegression().fit(X, sleep_efficiency_multi)

# Побудова прогнозу
age_range = np.linspace(min(age_multi), max(age_multi), 100).reshape(-1, 1)
sleep_duration_range = np.linspace(min(sleep_duration_multi), max(sleep_duration_multi), 100).reshape(-1, 1)
X_range = np.column_stack((age_range.ravel(), sleep_duration_range.ravel()))
sleep_efficiency_pred = model_multiple.predict(X_range)

# Побудова графіка
plt.figure(figsize=(10, 6))
plt.scatter(age_multi, sleep_duration_multi, c=sleep_efficiency_multi, cmap='viridis')
plt.plot(age_range, sleep_duration_range, sleep_efficiency_pred.reshape(age_range.shape), color='red')
plt.colorbar(label='Sleep efficiency')
plt.xlabel('Age')
plt.ylabel('Sleep duration')
plt.title('Множинна лінійна регресія: Sleep efficiency ~ Age + Sleep duration')
plt.savefig('linear_regression_model2.png')
plt.show()

# Метрики

# Оцінка моделі 1

from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

# Побудова прогнозу
sleep_efficiency_pred_simple = model_simple.predict(sleep_duration_simple)

# Оцінка моделі
r2_simple = r2_score(sleep_efficiency_simple, sleep_efficiency_pred_simple)
mse_simple = mean_squared_error(sleep_efficiency_simple, sleep_efficiency_pred_simple)
mae_simple = mean_absolute_error(sleep_efficiency_simple, sleep_efficiency_pred_simple)

print("Проста лінійна регресія:")
print("R^2:", r2_simple)
print("MSE:", mse_simple)
print("MAE:", mae_simple)


# Оцінка моделі 2

# Ініціалізація та навчання моделі множинної лінійної регресії
X_multiple = np.concatenate((age_multi, sleep_duration_multi), axis=1)
model_multiple = LinearRegression().fit(X_multiple, sleep_efficiency_multi)

# Побудова прогнозу
sleep_efficiency_pred_multiple = model_multiple.predict(X_multiple)

# Оцінка моделі
r2_multiple = r2_score(sleep_efficiency_multi, sleep_efficiency_pred_multiple)
mse_multiple = mean_squared_error(sleep_efficiency_multi, sleep_efficiency_pred_multiple)
mae_multiple = mean_absolute_error(sleep_efficiency_multi, sleep_efficiency_pred_multiple)

print("Множинна лінійна регресія:")
print("R^2:", r2_multiple)
print("MSE:", mse_multiple)
print("MAE:", mae_multiple)

# Порівняння

# Побудова прогнозу для моделі 1
sleep_duration_pred_simple = np.linspace(min(sleep_duration_simple), max(sleep_duration_simple), 100).reshape(-1, 1)
sleep_efficiency_pred_simple = model_simple.predict(sleep_duration_pred_simple)

# Побудова графіка для моделі 1
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.scatter(sleep_duration_simple, sleep_efficiency_simple, color='blue', label='Справжні дані')
plt.plot(sleep_duration_pred_simple, sleep_efficiency_pred_simple, color='red', linewidth=2, label='Прогнозовані дані')
plt.xlabel('Тривалість сну')
plt.ylabel('Ефективність сну')
plt.title('Проста лінійна регресія: Sleep efficiency ~ Sleep duration')
plt.legend()

# Побудова прогнозу для моделі 2
sleep_duration_range = np.linspace(min(sleep_duration_multi), max(sleep_duration_multi), 100).reshape(-1, 1)
age_range = np.linspace(min(age_multi), max(age_multi), 100).reshape(-1, 1)
X_range = np.column_stack((age_range.ravel(), sleep_duration_range.ravel()))
sleep_efficiency_pred_multi = model_multiple.predict(X_range)

# Побудова графіка для моделі 2
plt.subplot(1, 2, 2)
plt.scatter(age_multi, sleep_efficiency_multi, c=sleep_duration_multi, cmap='viridis', label='Справжні дані')
plt.colorbar(label='Тривалість сну')
plt.plot(age_range, sleep_efficiency_pred_multi, color='red', label='Прогнозовані дані')
plt.xlabel('Вік')
plt.ylabel('Ефективність сну')
plt.title('Множинна лінійна регресія: Sleep efficiency ~ Age + Sleep duration')
plt.legend()

plt.tight_layout()
plt.savefig('linear_regression_prognoses.png')
plt.show()
