# import numpy as np
# import matplotlib.pyplot as plt
# from sklearn.linear_model import LinearRegression
#
# # Надані дані
# sleep_duration = np.array([6.0, 7.0, 8.0, 6.0, 8.0, 6.0, 10.0, 6.0, 9.0, 8.0]).reshape(-1, 1)
# age = np.array([65, 69, 40, 40, 57, 27, 53, 41, 11, 50]).reshape(-1, 1)
# sleep_efficiency = np.array([0.88, 0.66, 0.89, 0.51, 0.76, 0.54, 0.9, 0.79, 0.55, 0.92])
#
# # Підготовка ознак для моделі
# X = np.concatenate((age, sleep_duration), axis=1)
#
# # Ініціалізація та навчання моделі
# model = LinearRegression().fit(X, sleep_efficiency)
#
# # Побудова прогнозу
# age_range = np.linspace(min(age), max(age), 100).reshape(-1, 1)
# sleep_duration_range = np.linspace(min(sleep_duration), max(sleep_duration), 100).reshape(-1, 1)
# X_range = np.column_stack((age_range.ravel(), sleep_duration_range.ravel()))
# sleep_efficiency_pred = model.predict(X_range)
#
# # Побудова графіка
# plt.figure(figsize=(10, 6))
# plt.scatter(age, sleep_duration, c=sleep_efficiency, cmap='viridis')
# plt.plot(age_range, sleep_duration_range, sleep_efficiency_pred.reshape(age_range.shape), color='red')
# plt.colorbar(label='Sleep efficiency')
# plt.xlabel('Age')
# plt.ylabel('Sleep duration')
# plt.title('Множинна лінійна регресія: Sleep efficiency ~ Age + Sleep duration')
# plt.savefig('linear_regression_model2.png')
# plt.show()

from sklearn.linear_model import LinearRegression
import numpy as np

# Дані для Моделі 1
sleep_duration = np.array([[6.0], [7.0], [8.0], [6.0], [8.0], [6.0], [10.0], [6.0], [9.0], [8.0]])
sleep_efficiency = np.array([0.88, 0.66, 0.89, 0.51, 0.76, 0.54, 0.9, 0.79, 0.55, 0.92])

# Виконуємо просту лінійну регресію для Моделі 1
model1 = LinearRegression()
model1.fit(sleep_duration, sleep_efficiency)

# Виведемо параметри моделі
print("Модель 1:")
print("Коефіцієнт навчання (slope):", model1.coef_[0])
print("Вільний член (intercept):", model1.intercept_)

# Графічне представлення результатів
import matplotlib.pyplot as plt

plt.scatter(sleep_duration, sleep_efficiency, color='blue')
plt.plot(sleep_duration, model1.predict(sleep_duration), color='red')
plt.title('Модель 1: Проста лінійна регресія')
plt.xlabel('Sleep duration')
plt.ylabel('Sleep efficiency')
plt.savefig('linear_regression_model1.png')
# plt.show()


# Дані для Моделі 2
age = np.array([[65, 6.0], [69, 7.0], [40, 8.0], [40, 6.0], [57, 8.0], [27, 6.0], [53, 10.0], [41, 6.0], [11, 9.0], [50, 8.0]])
sleep_efficiency = np.array([0.88, 0.66, 0.89, 0.51, 0.76, 0.54, 0.9, 0.79, 0.55, 0.92])

# Виконуємо множинну лінійну регресію для Моделі 2
model2 = LinearRegression()
model2.fit(age, sleep_efficiency)

# Виведемо параметри моделі
print("\nМодель 2:")
print("Коефіцієнти навчання (coefficients):", model2.coef_)
print("Вільний член (intercept):", model2.intercept_)

# Графічне представлення результатів
plt.scatter(age[:, 0], sleep_efficiency, color='blue', label='Age')
plt.scatter(age[:, 1], sleep_efficiency, color='green', label='Sleep duration')
plt.plot(age[:, 0], model2.predict(age), color='red')
plt.title('Модель 2: Множинна лінійна регресія')
plt.xlabel('Age and Sleep duration')
plt.ylabel('Sleep efficiency')
plt.legend()
# plt.show()
plt.savefig('linear_regression_model2.png')
