fruits = ["apple", "orange", "kiwi", "mango", "rosberry"]

for fruit in fruits:
    print(fruit)