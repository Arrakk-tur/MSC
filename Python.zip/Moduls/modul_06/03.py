import shutil


# shutil.make_archive("old_g", "zip", "Moduls/modul_06/mock")

# shutil.unpack_archive("old_g.zip", "un_ziped")

