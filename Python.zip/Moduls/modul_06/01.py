# f = open("Moduls/modul_06/", mode="x+")
# f.seek(0)
# f.readlines()
# f.close()

# with open("Moduls/modul_06/Binar.bin", "+wb") as f:
#     mes = "Hello duck".encode("cp1251")
#     f.write(mes)

