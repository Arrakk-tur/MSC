# import random




# numbers = [random.randint(0, 200) for _ in range(5)]
# print(numbers)

# sor_num = sorted(numbers)
# attemp = 0



# # сортування типом рандом

# while sor_num != numbers:
#     random.shuffle(numbers)
#     attemp += 1

# print(f"attemp {attemp}")
# print(numbers)


