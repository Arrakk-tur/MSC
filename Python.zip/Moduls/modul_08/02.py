from datetime import datetime, date


# 2568988
# 0433003

# print(datetime.MAXYEAR, datetime.MINYEAR)

# today = datetime(year=2024, month=2, day=22, hour=16)
# today = date(year=2024, month=2, day=22)

# print(datetime.today())
# print(datetime.now())

# d = "12.10.2023"

# res = datetime.strptime(d, "%d.%m.%Y")
# print(type(res), res)       #<class 'datetime.datetime'> 2023-10-12 00:00:00



# print(res.strftime("%A"))       # Thursday

# start = date(year=2022, month=2, day=24)

# today = date.today()

# print(today - start)

